﻿using System;
using System.Collections.Generic;

namespace shop
{
    // Define all available fruits with their prices in pence
    public enum Fruit {
        Orange = 60,
        Apple = 25
    };

    public class Checkout
    {
        /// <summary>
        /// Totals the price of the items in the supplied list
        /// </summary>
        /// <param name="itemList"></param>
        /// <returns>Total representing a major currency price</returns>
        public Decimal TotalItems(List<Fruit> itemList)
        {
            int total = 0;

            // Iterate over the list, grabbing the price in pence from the enum
            foreach (var item in itemList)
            {
                total += (int)item;
            }

            // Total is in pence - convert it to GBP for returning
            return (decimal) total / (decimal) 100.0;
        }

        private static void Main(string [] args)
        {
            // Create main function to satisfy compiler but doesn't do anything
            ;
        }
    }
}
