﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using shop;

namespace shop.Tests
{

    [TestClass()]
    public class CheckoutTests
    {

        // Independently define the prices
        private decimal ORANGE = 0.60m;
        private decimal APPLE = 0.25m;

        [TestMethod()]
        public void testEmptyList()
        {
            // Test supplying a list of no items - should total £0.00
            Checkout c = new Checkout();
            List<Fruit> list = new List<Fruit>();
            Assert.AreEqual(0.0m, c.totalItems(list));
        }

        [TestMethod()]
        public void testThreeOranges()
        {
            // Test supplying a list of 3 oranges - should total 3 x 0.60
            Checkout c = new Checkout();
            
            List<Fruit> list = new List<Fruit>(new Fruit[] { Fruit.Orange, Fruit.Orange, Fruit.Orange });
            Assert.AreEqual(3 * ORANGE, c.totalItems(list));
        }

        [TestMethod()]
        public void testTwoApples()
        {
            // Test supplying a list of 2 apples - should total 2 x 0.25
            Checkout c = new Checkout();
            List<Fruit> list = new List<shop.Fruit>(new Fruit[] { Fruit.Apple, Fruit.Apple });
            Assert.AreEqual(2 * APPLE, c.totalItems(list));
        }

        [TestMethod()]
        public void testOneAppleOneOrange()
        {
            // Test supplying a list of one apple and one orange - should total 0.60 + 0.25
            Checkout c = new Checkout();
            List<shop.Fruit> list = new List<shop.Fruit>(new shop.Fruit[] { Fruit.Apple, Fruit.Orange });
            Assert.AreEqual(APPLE + ORANGE, c.totalItems(list));
        }

        [TestMethod()]
        public void testAppleOrangeMix()
        {
            // Test supplying an unordered list of apples and oranges - should total 4 x 0.60 + 3 x 0.25
            Checkout c = new Checkout();
            List<shop.Fruit> list = new List<shop.Fruit>(new shop.Fruit[] { Fruit.Apple, Fruit.Orange, Fruit.Orange, Fruit.Apple, Fruit.Orange, Fruit.Orange, Fruit.Apple });
            Assert.AreEqual((4 * ORANGE) + (3 * APPLE), c.totalItems(list));
        }

        [TestMethod()]
        public void testVeryBigList()
        {
            // Test supplying a very big list
            int numApples = 32000000;
            int numOranges = 6400000;

            Checkout c = new Checkout();
            List<shop.Fruit> list = new List<shop.Fruit>(new shop.Fruit[] { });

            for (int i = 0; i < numApples; i++)
            {
                list.Add(Fruit.Apple);
            }
            for (int i = 0; i < numOranges; i++)
            {
                list.Add(Fruit.Orange);
            }
            Assert.AreEqual((numOranges * ORANGE) + (numApples * APPLE), c.totalItems(list));
        }
 
        [TestMethod()]
        public void testMutltipleCalls()
        {
            // Test calling the same Checkout instance multiple times - there should be no contamination between calls
            Checkout c = new Checkout();
            List<shop.Fruit> list = new List<shop.Fruit>(new shop.Fruit[] { Fruit.Apple, Fruit.Orange, Fruit.Orange, Fruit.Apple });
            Assert.AreEqual((2 * ORANGE) + (2 * APPLE), c.totalItems(list));

            // Add an orange to the list and try again
            list.Add(Fruit.Orange);
            Assert.AreEqual((3 * ORANGE) + (2 * APPLE), c.totalItems(list));

            // And then remove all oranges - should leave two apples
            list.RemoveAll(item => item == Fruit.Orange);
            Assert.AreEqual(2 * APPLE, c.totalItems(list));
        }
    }
}